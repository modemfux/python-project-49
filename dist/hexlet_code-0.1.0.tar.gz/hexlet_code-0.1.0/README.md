### Hexlet tests and linter status:
[![Actions Status](https://github.com/modemfux/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/modemfux/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/354794dcad51932d684a/maintainability)](https://codeclimate.com/github/modemfux/python-project-49/maintainability)
