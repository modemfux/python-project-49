### Hexlet tests and linter status:
[![Actions Status](https://github.com/modemfux/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/modemfux/python-project-49/actions)

### CodeClimate Maintainability
[![Maintainability](https://api.codeclimate.com/v1/badges/354794dcad51932d684a/maintainability)](https://codeclimate.com/github/modemfux/python-project-49/maintainability)

#### Asciinema for brain-even game
https://asciinema.org/a/7ssUcxHbBu51z33pC6PwOrnfY

#### Asciinema for brain-calc game
https://asciinema.org/a/4RJdVHSgEqtoxvVUhTPCaUPkv

#### Asciinema for brain-gcd game
https://asciinema.org/a/SdLbAQqp7ye5XmJr4AvOikCEa

#### Asciinema for brain-progression game
https://asciinema.org/a/MEtuv0CZqLbuTO6NtuRocwt8R
