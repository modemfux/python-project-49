import math


def gcd_logic(num1, num2):
    question = f'{num1} {num2}'
    return (question, str(math.gcd(num1, num2)))
